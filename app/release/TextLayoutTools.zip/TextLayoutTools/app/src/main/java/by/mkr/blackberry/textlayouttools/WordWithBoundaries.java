package by.mkr.blackberry.textlayouttools;

public class WordWithBoundaries {
    public String Word;
    public int Begin;
    public int End;

    public WordWithBoundaries(String word, int begin, int end) {
        Word = word;
        Begin = begin;
        End = end;
    }
}
